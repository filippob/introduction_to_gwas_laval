#' Function calculate genomic relationship matrix à la Van Raden
#'
#' This function allows you to set up the G-matrix à la Van Raden
#' @param M: n x m matrix of 0/1/2 coded SNP genotypes
#' @keywords g-matrix, van Raden
#' @export
#' @examples
#' not yet
#'

gVanRaden <- function(M) {

	M<-M-1;

	# COMPUTE ALLELE FREQUENCIES

	# this is to make sure that every SNP has the 3 genotype classes (-1, 0 , 1)
	f <- matrix(c(rep(-1,dim(M)[2]),rep(0,dim(M)[2]),rep(1,dim(M)[2])),nrow=3,byrow=TRUE);
	storage.mode(f) <- 'integer';
	F1 <- rbind(M,f);

	F2 <- unlist(apply(F1,2,table));
	F2 <- F2-1; 	# to remove the artificially added SNP genotypes (1 per genotype class)

	# vector (fr) of SNP allele frequencies
	fr <- (F2[3,]+F2[2,]/2)/colSums(F2);

	frsum <- (2*sum(fr*(1-fr))); 	#scaling factor for the G matrix by VanRaden, 2008
	freq.term <- 2*(fr-0.5); 	#vector p for "matrix" P to adjust M for allele frequencies and obtain Z


	## BUILD MATRIX OF GENOMIC RELATIONSHIPS

	MM <- M%*%t(M);

	AvgHomLoci <- mean(diag(MM));
	AvgSharedAll <- mean(MM[upper.tri(MM,diag=F)]);
	AvgHomInd <- mean(diag(t(M)%*%M));

	Z<-M;

	Z <- t(t(Z)-freq.term)

	GVR<-tcrossprod(Z)/frsum;

	GVR <- rescale(GVR,0,2);
	return(GVR)
}


#' Function calculate genomic relationship matrix à la Astle & Balding (2009)
#'
#' This function allows you to set up the G-matrix à la Astle & Balding (2009)
#' @param M: n x m matrix of 0/1/2 coded SNP genotypes
#' @keywords g-matrix, Astle & Balding
#' @export
#' @examples
#' gAstleBalding(matrix(sample(c(0,1,2),200,replace=TRUE), nrow=10))
#'

gAstleBalding <- function(M) {

	M <- M-1;

	# COMPUTE ALLELE FREQUENCIES

	# this is to make sure that every SNP has the 3 genotype classes (-1, 0 , 1)
	f <- matrix(c(rep(-1,dim(M)[2]),rep(0,dim(M)[2]),rep(1,dim(M)[2])),nrow=3,byrow=TRUE);
	storage.mode(f) <- 'integer';
	F1 <- rbind(M,f);

	F2 <- unlist(apply(F1,2,table));
	F2 <- F2-1; 	# to remove the artificially added SNP genotypes (1 per genotype class)

	# vector (fr) of SNP allele frequencies
	fr <- (F2[3,]+F2[2,]/2)/colSums(F2);

	frsum <- (2*sum(fr*(1-fr))); 	#scaling factor for the G matrix by VanRaden, 2008
	freq.term <- 2*(fr-0.5); 	#vector p for "matrix" P to adjust M for allele frequencies and obtain Z


	## BUILD MATRIX OF GENOMIC RELATIONSHIPS

	Z<-matrix(0,ncol=nrow(M),nrow=nrow(M));

	for(i in 1:ncol(M)) {

		m <- M[,i]
		m <- (m-2*freq.term[i])
		Z <- Z+(m %*% t(m))/(4*fr[i]*(1-fr[i]))
	}

	Z/ncol(M)->GAB;

	# library("scales")
	GAB <- rescale(GAB,0,2);

	return(GAB)
}

