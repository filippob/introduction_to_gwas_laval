#' Function to rescale data
#'
#' This function allows you to rescale your data between a new minimum and maximum (new range)
#' @param x vector of data (numeric),
#' @param newMin (integer)
#' @param newMax (integer)
#' @keywords rescale
#' @export
#' @examples
#' rescale(sample(runif(100),20),0,100)
#'

rescale <- function(x,newMin,newMax) {

  oldMax <-max(x);
  oldMin <-min(x);
  return((((newMax-newMin)*(x-oldMin))/(oldMax-oldMin))+newMin)
}

#' function to calculate MAF (vector of genotypes -0,1,2- as input)
#'
#' This function allows you to calculate the minor allele frequency (biallelic SNP)
#' @param vector of 0/1/2 genotypes
#' @keywords MAF
#' @export
#' @examples
#' maf(sample(c(0,1,2),20,replace=TRUE))


maf <- function(gv) {

  p <- (2*length(gv[gv==0]) + length(gv[gv==1]))/(2*length(gv));
  q <- 1 -p;
  return(min(p,q));
}

